package main

import "fmt"

func main() {
	var valorDolar float32
	var qtdeDolar float32
	fmt.Println("Insira o valor do dolar:")
	fmt.Scan(&valorDolar)
	fmt.Println("Insira a quantidade de dolares:")
	fmt.Scan(&qtdeDolar)

	var totalReais float32 = valorDolar * qtdeDolar
	fmt.Printf("Total em reais: R$%.2f", totalReais)

}
