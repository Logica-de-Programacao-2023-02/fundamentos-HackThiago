package main

import "fmt"

func main() {
	var base float32
	var altura float32
	var profundidade float32
	fmt.Println("Insira o valor da base:")
	fmt.Scan(&base)
	fmt.Println("Insira o valor da altura:")
	fmt.Scan(&altura)

	fmt.Println("Insira o valor da profundidade:")
	fmt.Scan(&profundidade)
	var volume float32 = base * altura * profundidade

	fmt.Printf("Volume da caixa: %.2f", volume)
}
